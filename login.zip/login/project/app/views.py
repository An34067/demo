from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView
from django.shortcuts import redirect
from .forms import UserWithPhoneCreationForm, RequestForm
from .models import *


class MyRegistrationView(CreateView):
    form_class = UserWithPhoneCreationForm
    template_name = "registration.html"
    success_url = reverse_lazy('login')


class CourseListView(ListView):
    model = Course
    template_name = "courses.html"
    context_object_name = "courses"
    paginate_by = 2


class CabinetView(CreateView):
    model = Request
    form_class = RequestForm
    template_name = "cabinet.html"
    success_url = reverse_lazy('cabinet')

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['requests'] = Request.objects.filter(user=self.request.user)
        return context