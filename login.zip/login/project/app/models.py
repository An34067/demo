from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, RegexValidator


class UserWithPhone(AbstractUser):
    phone = models.CharField(
        "Номер телефона",
        max_length=17,
        validators=[
            RegexValidator(r"^8 \(9\d{2}\) \d{3}-\d{2}-\d{2}$")
        ]
    )


class Course(models.Model):
    title = models.CharField("Название", max_length=255)
    image = models.ImageField(upload_to='courses/', blank=True, null=True)
    price = models.DecimalField(
        "Цена", max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    duration = models.CharField("Длительность", max_length=50)

    def __str__(self):
        return self.title 


class Request(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    status = models.CharField(
        choices=[
            ('new', 'Новая'),
            ('confirmed', 'Подтверждено'),
            ('completed', 'Завершено'),
        ],
        default='new',
        max_length=20
    )
    comment = models.TextField(blank=True, null=True)


class Comment(models.Model):
    request = models.ForeignKey(Request, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField(blank=True, null=True)