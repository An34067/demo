from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Request, UserWithPhone


class UserWithPhoneCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = UserWithPhone
        fields = ("username", "phone")


class RequestForm(forms.ModelForm):
    class Meta:
        model = Request
        fields = ('course', 'comment')