from django.contrib import admin
from .models  import *
# Register your models here.


admin.site.register(Request)
admin.site.register(UserWithPhone)
admin.site.register(Comment)
admin.site.register(Course)
