from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.CourseListView.as_view(), name='courses'),
    path('register/', views.MyRegistrationView.as_view(), name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='courses'), name='logout'),
    path('cabinet/', views.CabinetView.as_view(), name='cabinet'),
]